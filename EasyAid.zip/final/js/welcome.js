function showWelcome() {
    document.getElementById("welcomeComp").style.display = "block";
    document.getElementById("checkListComp").style.display = "none";
    document.getElementById("loginComp").style.display = "none";
    document.getElementById("loginBtn-minor").style.display = "block";
  }
  
  function showCheckList() {
    document.getElementById("welcomeComp").style.display = "none";
    document.getElementById("checkListComp").style.display = "block";
  }
  
  function areAllChecked() {
    var form = document.getElementById("checkboxes");
    var checkboxes = form.getElementsByTagName("input");
    var allChecked = false;
    for (var x = 0; x < checkboxes.length; x++) {
      if (checkboxes[x].type == "checkbox") {
        allChecked = checkboxes[x].checked;
        if (!allChecked) break;
      }
    }
    if (allChecked) {
      document.getElementById("continue1").style.display = "block";
    } else {
      document.getElementById("continue1").style.display = "none";
    }
  }
  
  function showLoginForm() {
    document.getElementById("welcomeComp").style.display = "none";
    document.getElementById("checkListComp").style.display = "none";
    document.getElementById("loginComp").style.display = "block";
    document.getElementById("loginBtn-minor").style.display = "none";
  }
  
  function areEmailPasswordFilled() {
    console.log("hihi");
    var email = document.getElementById("inputEmail").value;
    var password = document.getElementById("inputPassword").value;
    if (email != "" && password != "") {
      document.getElementById("loginBtn").style.display = "block";
    } else {
      document.getElementById("loginBtn").style.display = "none";
    }
  }
  
  