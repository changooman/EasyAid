var jobLossPerson, jobLossAmount, benefitAmount, benefitFrequency;

function checkFinancial() {
  var form = document.getElementById("checkboxes");
  var checkboxes = form.getElementsByTagName("input");
  for (var x = 0; x < checkboxes.length; x++) {
    if (checkboxes[x].type == "checkbox") {
      if (checkboxes[x].checked) {
        document.getElementById("continueFinancial").style.display =
          "inline-block";
          document.getElementById("savedChange1").style.display = "inline-block";
        
        return;
      }
    }
  }
  document.getElementById("continueFinancial").style.display = "none";
  document.getElementById("savedChange1").style.display = "none";
}

function checkLoss() {
  var jobloss = document.getElementById("jobLossSelection");
  var person = jobloss.value;
  var amount = document.getElementById("lossAmount").value;
  jobLossPerson = person;
  jobLossAmount = amount;
  if (person != 0 && amount != "") {
    document.getElementById("continueLoss").style.display = "inline-block";
    document.getElementById("savedChange2").style.display = "inline-block";
    return;
  } else {
    document.getElementById("continueLoss").style.display = "none";
    document.getElementById("savedChange2").style.display = "none";
  }
}

function checkBenefits() {
  var amount = document.getElementById("benefitAmount").value;
  var frequency = document.getElementById("benefitFrequency").value;
  benefitAmount = amount;
  benefitFrequency = frequency;
  if (amount != "" && frequency != 0) {
    document.getElementById("continueBenefit").style.display = "inline-block";
    document.getElementById("savedChange3").style.display = "inline-block";
    return;
  } else {
    document.getElementById("continueBenefit").style.display = "none";
    document.getElementById("savedChange3").style.display = "none";
  }
}

function showLossJob() {
  document.getElementById("benefits").style.display = "none";
  document.getElementById("financialChange").style.display = "none";
  document.getElementById("lossOfJob").style.display = "block";
}

function showFinancialChange() {
  document.getElementById("financialChange").style.display = "block";
  document.getElementById("lossOfJob").style.display = "none";
}

function showBenefits() {
  document.getElementById("lossOfJob").style.display = "none";
  document.getElementById("reviewSubmission").style.display = "none";
  document.getElementById("benefits").style.display = "block";
}

function showReview() {
  document.getElementById("benefits").style.display = "none";
  document.getElementById("reviewSubmission").style.display = "block";

  document.getElementById("jobLossPerson").innerHTML = this.jobLossPerson;
  document.getElementById("jobLossAmount").innerHTML = this.jobLossAmount;
  var benefitAmountFreq =
    "$" + this.benefitAmount + " (" + this.benefitFrequency + ")";
  document.getElementById("benefitAmountFreq").innerHTML = benefitAmountFreq;
}

function showComplete() {
  document.getElementById("reviewSubmission").style.display = "none";
  document.getElementById("complete").style.display = "block";
}

