function isFilled() {
  var email = document.getElementById("recipient-email").value;
  if(email != ""){
    document.getElementById("cancelButton").style = "height: 67px; width: 129px;";
    document.getElementById("sendEmailButton").style.display = "inline-block";
  } else {
    document.getElementById("cancelButton").style = "height: 67px; width: 258px;";
    document.getElementById("sendEmailButton").style.display = "none";
  }
}

function sendEmail() {
    var emailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    var emailAddress = document.getElementById("recipient-email").value;
    if (emailAddress.match(emailformat)) {
      console.log("valid");
      document
        .getElementById("sendEmailButton")
        .setAttribute("data-dismiss", "modal");
      document
        .getElementById("sendEmailButton")
        .setAttribute("data-toggle", "modal");
      document
        .getElementById("sendEmailButton")
        .setAttribute("href", "#exampleModalCenter2");
      document.getElementById("receiver").innerHTML = emailAddress;
    } else {
      document.getElementById("invalidEmail").style.display = "block";
    }
  }
  
  function resetInvalidAlert() {
    document.getElementById("recipient-email").value = "";
  
    document.getElementById("invalidEmail").style.display = "none";
  
    document.getElementById("sendEmailButton").removeAttribute("data-dismiss");
  
    document.getElementById("sendEmailButton").removeAttribute("data-toggle");
  
    document.getElementById("sendEmailButton").removeAttribute("href");
  
    document.getElementById("receiver").innerHTML = "";
  }
  
  